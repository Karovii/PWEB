document.addEventListener('DOMContentLoaded', () => {
    const botaoJogar = document.getElementById('jogar');
    const resultado = document.getElementById('resultado');

    botaoJogar.addEventListener('click', () => {
        const escolhaJogador = document.getElementById('jogador').value;
        const escolhaComputador = fazerEscolhaComputador();
        const resultadoJogo = determinarVencedor(escolhaJogador, escolhaComputador);
        resultado.textContent = `Você escolheu: ${escolhaJogador}. O computador escolheu: ${escolhaComputador}. ${resultadoJogo}`;
    });

    function fazerEscolhaComputador() {
        const random = Math.random();
        if (random < 0.33) {
            return 'pedra';
        } else if (random < 0.66) {
            return 'papel';
        } else {
            return 'tesoura';
        }
    }

    function determinarVencedor(jogador, computador) {
        if (jogador === computador) {
            return 'Empate!';
        } else if (
            (jogador === 'pedra' && computador === 'tesoura') ||
            (jogador === 'tesoura' && computador === 'papel') ||
            (jogador === 'papel' && computador === 'pedra')
        ) {
            return 'Você ganhou!';
        } else {
            return 'Você perdeu!';
        }
    }
});