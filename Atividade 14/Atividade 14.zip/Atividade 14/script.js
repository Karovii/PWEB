document.addEventListener("DOMContentLoaded", function () {
    const inputTexto = document.getElementById("texto");
    const radios = document.getElementsByName("transformacao");

    for (let i = 0; i < radios.length; i++) {
        radios[i].addEventListener("change", function () {
            if (this.checked) {
                if (this.value === "maiuscula") {
                    inputTexto.value = inputTexto.value.toUpperCase();
                } else if (this.value === "minuscula") {
                    inputTexto.value = inputTexto.value.toLowerCase();
                }
            }
        });
    }
});
