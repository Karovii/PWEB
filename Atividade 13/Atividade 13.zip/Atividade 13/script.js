(() => {
    const imagemJanela = document.getElementById('imagemJanela');
    const textoStatus = document.getElementById('textoStatus');
  
    let janelaQuebrada = false;
  
    function aoMouseEntrar() {
      if (janelaQuebrada) return;
      imagemJanela.src = 'janelaaberta.png';
      textoStatus.textContent = 'Janela aberta';
      imagemJanela.alt = 'Janela Aberta';
    }
  
    function aoMouseSair() {
      if (janelaQuebrada) return;
      imagemJanela.src = 'janelafechada.png';
      textoStatus.textContent = 'Janela Fechada';
      imagemJanela.alt = 'Janela Fechada';
    }
  
    function aoClicar() {
      if (janelaQuebrada) return;
      janelaQuebrada = true;
      imagemJanela.src = 'janelaquebrada.png';
      textoStatus.textContent = 'Janela Quebrada';
      imagemJanela.alt = 'Janela Quebrada';
    }
  
    imagemJanela.addEventListener('mouseover', aoMouseEntrar);
    imagemJanela.addEventListener('mouseout', aoMouseSair);
    imagemJanela.addEventListener('click', aoClicar);
  
    
    imagemJanela.addEventListener('touchstart', (e) => {
      e.preventDefault();
      if (janelaQuebrada) return;
      aoMouseEntrar();
    }, { passive: false });
  
    imagemJanela.addEventListener('touchend', (e) => {
      e.preventDefault();
      if (janelaQuebrada) return;
      aoMouseSair();
    }, { passive: false });
  })();
  