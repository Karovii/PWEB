function validar() {
    const form = document.nomeform.elements;
    const nome = form["nome"].value.trim();
    const email = form["email"].value.trim();
    const comentario = form["comentario"].value.trim();
    const pesquisa = document.querySelector('input[name="pesquisa"]:checked');

    if (nome.length < 10) {
        alert("O nome deve conter no mínimo 10 caracteres.");
        return false;
    }

    if (!email.includes("@")) {
        alert("Digite um e-mail válido.");
        return false;
    }

    if (comentario.length < 20) {
        alert("O comentário deve ter no mínimo 20 caracteres.");
        return false;
    }

    if (!pesquisa) {
        alert("Selecione uma opção na pesquisa.");
        return false;
    }

    if (pesquisa.value === "nao") {
        alert("Que bom que você voltou a visitar esta página!");
    } else {
        alert("Volte sempre a esta página!");
    }

    return true;
}
