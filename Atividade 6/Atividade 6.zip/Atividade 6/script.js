function calcularMedia() {
    const nome = prompt("Digite o nome do aluno:");
    const nota1 = parseFloat(prompt("Digite a primeira nota:"));
    const nota2 = parseFloat(prompt("Digite a segunda nota:"));
    const nota3 = parseFloat(prompt("Digite a terceira nota:"));
    const nota4 = parseFloat(prompt("Digite a quarta nota:"));

    if (isNaN(nota1) || isNaN(nota2) || isNaN(nota3) || isNaN(nota4)) {
        alert("Por favor, insira valores válidos para as notas.");
        return;
    }

    const media = (nota1 + nota2 + nota3 + nota4) / 4;

    alert(`A média final de ${nome} é: ${media.toFixed(2)}`);
}

function realizarOperacoes() {
    const num1 = parseFloat(prompt("Digite o primeiro número:"));
    const num2 = parseFloat(prompt("Digite o segundo número:"));

    if (isNaN(num1) || isNaN(num2)) {
        alert("Por favor, insira valores válidos para os números.");
        return;
    }

    const soma = num1 + num2;
    const subtracao = num1 - num2;
    const produto = num1 * num2;
    const divisao = num2 !== 0 ? (num1 / num2) : "Divisão por zero não é permitida";
    const resto = num2 !== 0 ? (num1 % num2) : "Divisão por zero não é permitida";

    alert(`Resultados:\nSoma: ${soma}\nSubtração: ${subtracao}\nProduto: ${produto}\nDivisão: ${divisao}\nResto: ${resto}`);
}