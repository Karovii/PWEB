function maiorDeTres(num1, num2, num3) {
    return Math.max(num1, num2, num3);
}

function mostrarMaior() {
    const num1 = parseFloat(document.getElementById('num1').value);
    const num2 = parseFloat(document.getElementById('num2').value);
    const num3 = parseFloat(document.getElementById('num3').value);
    const maior = maiorDeTres(num1, num2, num3);
    document.getElementById('resultadoMaior').innerText = `O maior número é: ${maior}`;
}


function ordemCrescente(num1, num2, num3) {
    return [num1, num2, num3].sort((a, b) => a - b);
}

function mostrarOrdemCrescente() {
    const num1 = parseFloat(document.getElementById('num4').value);
    const num2 = parseFloat(document.getElementById('num5').value);
    const num3 = parseFloat(document.getElementById('num6').value);
    const ordem = ordemCrescente(num1, num2, num3);
    document.getElementById('resultadoOrdem').innerText = `Números em ordem crescente: ${ordem.join(', ')}`;
}


function ehPalindromo(str) {
    const strMaiuscula = str.toUpperCase();
    const strInvertida = strMaiuscula.split('').reverse().join('');
    return strMaiuscula === strInvertida;
}

function verificarPalindromo() {
    const str = document.getElementById('stringPalindromo').value;
    const resultado = ehPalindromo(str);
    document.getElementById('resultadoPalindromo').innerText = resultado ? 'É um palíndromo!' : 'Não é um palíndromo.';
}


function verificarTipoTriangulo(lado1, lado2, lado3) {
    if (lado1 + lado2 > lado3 && lado1 + lado3 > lado2 && lado2 + lado3 > lado1) {
        if (lado1 === lado2 && lado2 === lado3) {
            return 'Triângulo Equilátero';
        } else if (lado1 === lado2 || lado1 === lado3 || lado2 === lado3) {
            return 'Triângulo Isósceles';
        } else {
            return 'Triângulo Escaleno';
        }
    } else {
        return 'Os valores não formam um triângulo.';
    }
}

function verificarTriangulo() {
    const lado1 = parseFloat(document.getElementById('lado1').value);
    const lado2 = parseFloat(document.getElementById('lado2').value);
    const lado3 = parseFloat(document.getElementById('lado3').value);
    const resultado = verificarTipoTriangulo(lado1, lado2, lado3);
    document.getElementById('resultadoTriangulo').innerText = resultado;
}